# 🖼 Get YouTube Thumbnail
![](https://img.shields.io/github/license/rdavydov/get-yt-thumb?style=for-the-badge&logo=github&color=purple&logoColor=thistle)
![](https://img.shields.io/github/stars/rdavydov/get-yt-thumb?style=for-the-badge&logo=github&color=darkblue&logoColor=aquamarine)
![](https://img.shields.io/github/forks/rdavydov/get-yt-thumb?style=for-the-badge&logo=github&color=darkblue&logoColor=aquamarine)
![](https://img.shields.io/github/watchers/rdavydov/get-yt-thumb?style=for-the-badge&logo=github&color=darkblue&logoColor=aquamarine)
![](https://img.shields.io/website?down_color=darkred&up_color=darkgreen&url=https%3A%2F%2Frdavydov.github.io%2Fget-yt-thumb%2F&logo=github&logoColor=green&style=for-the-badge)

<https://rdavydov.github.io/get-yt-thumb/>

Supports .be, shorts, embed, with timestamps and other clutter

![](https://raw.githubusercontent.com/rdavydov/get-yt-thumb/master/screenshot.png)
